CATKIN_SHELL=zsh
. /etc/ros-groovy/setup.sh
