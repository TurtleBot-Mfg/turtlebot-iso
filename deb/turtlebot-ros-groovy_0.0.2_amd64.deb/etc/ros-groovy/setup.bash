#!/bin/bash
CATKIN_SHELL=bash
. /etc/ros-groovy/setup.sh
