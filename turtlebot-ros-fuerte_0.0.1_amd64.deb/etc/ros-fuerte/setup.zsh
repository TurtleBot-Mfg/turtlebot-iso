CATKIN_SHELL=zsh
. /etc/ros-fuerte/setup.sh
